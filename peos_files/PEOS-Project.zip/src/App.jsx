export default function App(){
  return <div style={{textAlign:'center', marginTop:'50px', fontFamily:'Arial'}}>
    <h1>PEOS Auto Built ✅</h1>
    <p>Run: npm install && npm run dev</p>
  </div>
}